# Student-Management-System
Live Link : https://studentmanagement007.herokuapp.com/


Question 1 :- Design a Student Management System   In this project user have Administrator  roles and he should be able to  add , update and delete the student.
see all details of students.  categories the student on the basis of total marks  (For example :- marks >= 90 = A grade , 90>marks >=80 , B grade , 80>marks>=70 ,
C grade , 70>marks>=60 , D grade , 60>marks>=50 , E grade, marks&lt;50 = Fail )  see the total number of passed students and total number of failed students.
